//  Final Project 
//
//	C-212
//
//  @Author Evan Brinckman and ebrinckm
//
//	Last edited: 4/12/2019
//
//////////////////////////////////////
package System;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Database {
	
	protected ArrayList<Profile> elements;
	protected ArrayList<Credential> creds;
	protected ArrayList<Activity> act;
	protected String directoryName;
	protected String fileName;
	protected File directoryFile;
	protected File profileFile;
	protected Scanner profileReader;
	protected Scanner sectionReader;
	protected PrintWriter out;
	private PrintWriter credWriter;
	
	
	
	//Constructor
	public Database(String directoryName) throws FileNotFoundException {
		this.directoryName = directoryName;
		this.directoryFile = new File(this.directoryName);
		this.credWriter = new PrintWriter("src\\CredentialsFile\\Credentials.txt");
	}
	
	public void buildDatabase() throws FileNotFoundException {
		BufferedReader reader = new BufferedReader(new FileReader(this.fileName));
		String[] holder;
		ArrayList<String> holder2= new ArrayList<String>();
		try {
			String line;
			while ((line = reader.readLine()) != null) {
				holder = line.split(" ");
				holder2.add(holder[1]);
				this.elements.add((Profile) new Object());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		//TO DO: builds data base from file.
		return;
	}
	
	//Getter for elements.
	public ArrayList<Profile> getElements() {
		return this.elements;
	}
	
	public ArrayList<Credential> getCred() {
		return this.creds;
	}
	
	//New profiles will be added here
	public void addElement(Profile obj) {
		this.elements.add(obj);
	}
	
	//New Credentials go into here.
	public void addCred(Credential obj) {
		this.creds.add(obj);
	}
	
	//New activities go into here.
	public void addAct(Activity obj) {
		this.act.add(obj);
	}
	
	public void updateDatabase() throws FileNotFoundException {
		for(Profile p : this.elements) {
			String file = this.directoryName + "\\" + p.getFirstName() + p.getLastName() + ".txt";
			PrintWriter pWriter = new PrintWriter(file);
			pWriter.print(p);
			pWriter.close();
		}
		for(Credential cred : this.creds) {
			this.credWriter.print(cred);
		}
		credWriter.close();
	}
	
	public void closeDatabase() {
		//Closes files for Database
		this.profileReader.close();
		this.sectionReader.close();
		this.out.close();
		return;
	}
	
	
	
}
