//  Final Project
//
//	C-212
//
//  @Author Zachary Reid and zrreid
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

public class Appointment extends Activity {
	private final String PATIENT;
	private String doctor;
	private String appointmentType;
	private String reasonForAppointment;
	private String notes;
	
	//Constructor
	public Appointment(String patientID, String doctorID, String date, String appointmentType, String roomNumber, String description) {
		super("Ap", date, roomNumber);
		this.PATIENT = patientID;
		this.doctor = doctorID;
		this.appointmentType = appointmentType;
		this.reasonForAppointment = description;
		this.notes = "";
	}
	
	//Returns the patient who scheduled the appointment
	public String getPatient() { return this.PATIENT; }
	
	//Sets the doctor holding the appointment
	public void setDoctor(String doctorID) { this.doctor = doctorID; }
	
	//Returns the doctor holding the appointment
	public String getDoctor() { return this.doctor; }
	
	//Sets the appointment type
	public void setAppointmentType(String type) { this.appointmentType = type; }
	
	//Returns appointment type
	public String getAppointmentType() { return this.appointmentType; }
	
	//Sets the reason for the appointment
	public void setReasonForAppointment(String reason) { this.reasonForAppointment = reason; }
	
	//Returns the reason for the appointment
	public String getReasonForAppointment() { return this.reasonForAppointment; }
	
	//Add notes to the appointment's notes
	public void addNotes(String notes) { this.notes += "\n" + notes; }
	
	//Returns the notes for the appointment
	public String getNotes() { return this.notes; }
	
	//Overrides the toString method to produce better output
	public String toString() {
		String value = "";
		value += "ActivityID: " + this.getActivity();
		value += "\nPatient: " + this.PATIENT;
		value += "\nDoctors: " + this.doctor;
		value += "\nDate: " + this.getDate();
		value += "\nRoom Number: " + this.getRoomNumber();
		value += "\nAppointment Type: " + this.appointmentType;
		value += "\nReason for the Appointment: " + this.reasonForAppointment;
		value += "\nNotes:\n" + this.notes;
		return value;
	}
	//Test Client
	public static void main(String[] args) {
		Appointment test = new Appointment("Pt000001", "Dr000001", "04/26/2019", "Physical", "R101", "Patient complained too much.");
		System.out.println(test.getActivityType());
		System.out.println(test);
	}
}
