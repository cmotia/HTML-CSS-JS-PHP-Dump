//  Final Project 
//
//	C-212
//
//  @Author Evan Brinckman and ebrinckm
//
//	Last edited: 4/12/2019
//
//////////////////////////////////////
package System;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class AssistantDatabase extends Database {
	
	private ArrayList<String> holder2= new ArrayList<String>();
	private ArrayList<AssistantProfile> astProf= new ArrayList<AssistantProfile>();
	AssistantProfile ast;
	protected PrintWriter out;
	
	public AssistantDatabase() throws FileNotFoundException {
		super("src\\AssistantProfiles");
		this.readDatabase();
	}
	
	public void readDatabase() throws FileNotFoundException {
		File dir = new File(this.directoryName);
		File[] files = dir.listFiles();
		for(File f : files) {
			BufferedReader reader = new BufferedReader(new FileReader(f));
			String[] holder;
				try {
					String line;
					while ((line = reader.readLine()) != null) {
						holder = line.split(" ");
						this.holder2.add(holder[1]);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	
	public void buildDatabase() {
		Credential cred = new Credential(this.holder2.get(0), this.holder2.get(1),"At", "At");
		String ID = "At";
		String inputFile = super.fileName;
		String fName = this.holder2.get(3);
		String lName = this.holder2.get(4);
		String office = this.holder2.get(5);
		String number = this.holder2.get(6);
		String email = this.holder2.get(7);
		String hours = this.holder2.get(8);
		this.ast = new AssistantProfile(cred, ID, fName, lName, inputFile, number, email, office);
		super.addElement(this.ast);
		this.astProf.add(this.ast);
	}
	
	public void updateDatabase() {
		
	}
	
	public AssistantProfile getProfile(String name) {
		AssistantProfile found = null;
		//TO DO: Returns doctor profile based on search.
		for(AssistantProfile ast : this.astProf) {
			if (ast.getLastName().equals(name)) {
				found = ast;
			}
		}
		return found;
		}
}
	
