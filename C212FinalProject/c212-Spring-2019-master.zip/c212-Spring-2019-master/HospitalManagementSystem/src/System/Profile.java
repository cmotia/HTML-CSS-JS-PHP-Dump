//  Final Project
//
//	C-212
//
//  @Author Christopher Motia and cmotia
//
//	Last edited: 4/12/2019
//
//////////////////////////////////////
package System;

public class Profile {
    protected final Credential CREDENTIAL;
    protected final String ID;
    protected final String FNAME;
    protected final String LNAME;

    @Override
    public String toString() {
        return
                "CREDENTIAL=" + CREDENTIAL +
                ", ID='" + ID + '\n' +
                ", FNAME='" + FNAME + '\n' +
                ", LNAME='" + LNAME + '\n' +
                ", PROFILE_TYPE='" + PROFILE_TYPE + '\n' +
                ", PROFILE_SOURCE='" + PROFILE_SOURCE + '\n' +
                ", phoneNumber='" + phoneNumber + '\n' +
                ", email='" + email + '\n';
    }

    protected final String PROFILE_TYPE;
    protected final String PROFILE_SOURCE;
    protected String phoneNumber;
    protected String email;

    //profile has a name, credential, role
    public Profile(Credential credential, String ID, String fName, String lName, String type, String inputFile, String phoneNumber, String email) {
        //to do: constructor
    	this.PROFILE_TYPE = type;
    	this.PROFILE_SOURCE = inputFile;
    	this.LNAME = lName;
    	this.FNAME = fName;
    	this.ID = ID;
    	this.CREDENTIAL = credential;
    	this.phoneNumber = phoneNumber;
    	this.email = email;
    }

    public String getUserID() {
        //Returns the profiles userID
        return ID;
    }

    public String getFirstName() {
        //Returns the first name of the profile
        return FNAME;
    }

    public String getLastName() {
        //Returns the last name of the profile
        return LNAME;
    }

    public String getProfileType() {
        //Returns the type of the profile
        return PROFILE_TYPE;
    }

    public String getProfileSource() {
        //Returns the source path of the profile
        return PROFILE_SOURCE;
    }

    public void setPhoneNumber(String newPhoneNumber) {
        this.phoneNumber = newPhoneNumber;
    }

    public String getPhoneNumber() {
        //Returns the phone number of the profile
        return phoneNumber;
    }

    public void setEmail(String newEmail) {
        this.email = newEmail;
    }

    public String getEmail() {
        // Returns the email of the profile
        return email;
    }

    public Credential getCREDENTIAL() {
        return CREDENTIAL;
    }

    public String getID() {
        return ID;
    }

    public String getFNAME() {
        return FNAME;
    }

    public String getLNAME() {
        return LNAME;
    }

    public String getPROFILE_TYPE() {
        return PROFILE_TYPE;
    }

    public String getPROFILE_SOURCE() {
        return PROFILE_SOURCE;
    }
}
