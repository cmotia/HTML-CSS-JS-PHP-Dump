//  Final Project 
//
//	C-212
//
//  @Author Evan Brinckman and ebrinckm
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class AppointmentDatabase extends Database{
	
	private ArrayList<String> holder2= new ArrayList<String>();
	private ArrayList<Appointment> appt= new ArrayList<Appointment>();
	private Appointment apt;
	
	public AppointmentDatabase() throws FileNotFoundException {
		super("src\\Appointment");
		this.readDatabase();
	}
	
	public void readDatabase() throws FileNotFoundException {
		File dir = new File(this.directoryName);
		File[] files = dir.listFiles();
		for(File f : files) {
			BufferedReader reader = new BufferedReader(new FileReader(f));
			String[] holder;
				try {
					String line;
					while ((line = reader.readLine()) != null) {
						holder = line.split(" ");
						this.holder2.add(holder[1]);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	
	public void buildDatabase() {
		String patientID = this.holder2.get(0);
		String doctorID = this.holder2.get(1);
		String date = this.holder2.get(2);
		String appointmentType = this.holder2.get(3);
		String roomNumber = this.holder2.get(4);
		String description = this.holder2.get(5);
		this.apt = new Appointment(patientID,doctorID,date,appointmentType,roomNumber,description);
		super.addAct(this.apt);
		this.appt.add(this.apt);
	}
	//getter
	public ArrayList<Appointment> getAppt(){
		return this.appt;
	}
}
