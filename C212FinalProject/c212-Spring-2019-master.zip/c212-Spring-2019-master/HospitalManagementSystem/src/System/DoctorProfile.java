//  Final Project
//
//	C-212
//
//  @Author Christopher Motia and cmotia
//
//	Last edited: 4/12/2019
//
//////////////////////////////////////
package System;

import java.util.*;

public class DoctorProfile extends Profile {
    private final static String PROFILE_TYPE = "Doctor";
    private String specialty;
    private String office;
    private Schedule schedule;
    private String hours;

    public DoctorProfile(Credential credential, String ID, String fName, String lName, String inputFile, String phoneNumber, String email, String specialty, String office,String hours) {
        super(credential, ID, fName, lName, PROFILE_TYPE, inputFile, phoneNumber, email);
        this.specialty = specialty;
        this.office = office;
        this.hours = hours;
        //to do: constructor
    }

    public String getSpecialty() {
        //to do: Returns the profile's specialty
        return specialty;
    }

    public Schedule getSchedule() {
        //to do: Returns the schedule of the doctor
        return schedule;
    }

    public void setHours(String hours) {
        this.hours = hours;
    }

    public String getHours() {
        //to do: Returns the doctor's hours that they work
        return hours;
    }

    public void setOffice(String newOffice) {
        this.office = newOffice;
    }

    public String getOffice() {
        //to do: Returns the doctor's office
        return office;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return  "Username: " + this.getCREDENTIAL().getUsername() + '\n'+
                //gets username from credential
                "Password: " + this.getCREDENTIAL().getPassword() + '\n'+
                //gets password from credential
                "ProfileType: " + this.getPROFILE_TYPE() + '\n' +
                "UserID: " + this.getUserID() + '\n' +
                "FirstName: " +this.getFirstName() + '\n'+
                "LastName: " + this.getLastName() + '\n' +
                "Specialty: '" + this.specialty + '\n' +
                "Office: " + this.office + '\n' +
                "PhoneNumber: " + this.getPhoneNumber() + '\n'+
                "Email: " + this.getEmail() + '\n'+
                "hours: " + this.hours;
    }
}
