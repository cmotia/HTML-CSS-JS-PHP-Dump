//  Final Project 
//
//	C-212
//
//  @Author Evan Brinckman and ebrinckm
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CredentialDatabase extends Database{
	
	private ArrayList<String> holder2= new ArrayList<String>();
	private boolean isNext = false;

	public CredentialDatabase() throws FileNotFoundException {
		super("src\\CredentialsFile");
		//TO DO: Read data from file. Store data into Arraylist of Credential objects.
	}
	
	public void newLogin(String username, String password, String type, String ID) {
		Credential cred = new Credential(username,password,type, ID);
		if (this.verifyCredential(cred) == 0) {
			super.addCred(cred);
		}
		// TO DO: Checks whether username is unique, if so creates new Credential and adds it to collection.
		return;
	}
	
	public void readDatabase() throws FileNotFoundException {
		BufferedReader reader = new BufferedReader(new FileReader("Credentials.txt"));
		String[] holder;
		try {
			String line;
			while ((line = reader.readLine()) != null) {
				holder = line.split(" ");
				
				if (holder[0].equals("$")) {
					this.isNext = true;
					super.addCred(new Credential(this.holder2.get(0), this.holder2.get(1), this.holder2.get(2), this.holder2.get(3)));
					this.holder2.clear();
				}
				
				if (!this.isNext) {
					this.holder2.add(holder[1]);
				}
				
				this.isNext = false;
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		//TO DO: builds data base from file.
		return;
	}
	
	public void buildDatabase() {
		//TO DO: Writes new data back to file for storage.
		return;
	}
	
	public int verifyCredential(Credential c) {
		if (super.elements != null) {
			for (int i = 0; i < super.elements.size(); i++) {
				if (super.creds.get(i).getUsername().equals(c.getUsername())) {
					return 1;
				}
				if (!(super.creds.get(i).getUsername().equals(c.getUsername()))) {
					return 0;
				}
				if (!(super.creds.get(i).getPassword().equals(c.getPassword()))) {
					return 2;
				}
				if (!(super.creds.get(i).getType().equals(c.getType())));
				return 3;
			}
		}
		
		return 0;
		//TO DO: Returns 0 if username is unique, Returns 1 if credential exists in database
		//			Returns 2 if password is incorrect for specified username, Returns 3 if type is
		//			incorrect for the specified username and password.
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		CredentialDatabase test = new CredentialDatabase();
	}
}
