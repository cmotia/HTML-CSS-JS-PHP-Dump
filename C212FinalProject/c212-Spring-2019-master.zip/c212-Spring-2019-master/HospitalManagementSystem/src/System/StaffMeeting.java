//  Final Project
//
//	C-212
//
//  @Author Zachary Reid and zrreid
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

import java.util.*;

public class StaffMeeting extends Activity {
	private ArrayList<String> attendees;
	private String topic;
	private String notes;
	
	//Constructor
	public StaffMeeting(String topic, String date, String roomNumber) {
		super("SM", date, roomNumber);
		attendees = new ArrayList<>();
		this.topic = topic;
		this.notes = "";
	}
	
	//Adds attendees to the list of attendees
	public void addAttendees(String attendeeID) { this.attendees.add(attendeeID); }
	
	//Returns the list of attendees
	public ArrayList<String> getAttendees() { return this.attendees; }
	
	//Sets the topic for the meeting
	public void setTopic(String topic) { this.topic = topic; }
	
	//Returns topic for the meeting
	public String getTopic() { return this.topic; }	
	
	//Adds notes to the meeting's notes
	public void addNotes(String notes) { this.notes += "\n" + notes; }
	
	//Returns the notes for the meeting
	public String getNotes() { return this.notes; }
	
	//Overrides the toString method to produce better output
	public String toString() {
		String value = "";
		value += "ActivityID: " + this.getActivity();
		value += "\nAttendees: ";
		for(String attendee : attendees) { value += attendee + ", "; }
		value = value.substring(0, value.length() - 2);
		value += "\nDate: " + this.getDate();
		value += "\nRoom Number: " + this.roomNumber;
		value += "\nTopic of Meeting: " + this.topic;
		value += "\nNotes:\n" + this.notes;
		return value;
	}
	
	//Test Client
	public static void main(String[] args) {
		StaffMeeting test = new StaffMeeting("The Rats", "04/26/2019", "R102");
		test.addAttendees("Dr000001");
		test.addAttendees("At000001");
		test.addAttendees("Dr000002");
		System.out.println(test);
	}
}
