//  Final Project
//
//	C-212
//
//  @Author Christopher Motia and cmotia
//
//	Last edited: 4/12/2019
//
//////////////////////////////////////
package System;

import java.util.ArrayList;

public class PatientProfile extends Profile {
    private final static String PROFILE_TYPE = "Patient";
    private ArrayList<Appointment> appointmentHistory;

    public PatientProfile(Credential credential, String ID, String fName, String lName, String inputFile, String phoneNumber, String email) {
        super(credential, ID, fName, lName, PROFILE_TYPE, inputFile, phoneNumber, email);

    }

    public ArrayList<Appointment> getAppointmentHistory() {

        return appointmentHistory;
    }

    public void fillAppointmentHistory(String ID) {
        //to do: Fills the patient's appointment history
        //takse information from apointsments hashmap and compairs to users appointments
    }

    @java.lang.Override
    public java.lang.String toString() {
        return "Username: " + this.getCREDENTIAL().getUsername() + '\n'+
                //gets username from credential
                "Password: " + this.getCREDENTIAL().getPassword() + '\n'+
                //gets password from credential
                "ProfileType: " + this.getPROFILE_TYPE() + '\n' +
                "UserID: " + this.getUserID() + '\n' +
                "FirstName: " +this.getFirstName() + '\n'+
                "LastName: " + this.getLastName() + '\n' +
                "PhoneNumber: " + this.getPhoneNumber() + '\n'+
                "Email: " + this.getEmail() + '\n';

    }
}
