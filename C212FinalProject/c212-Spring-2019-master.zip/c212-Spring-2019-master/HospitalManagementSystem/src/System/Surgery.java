//  Final Project
//
//	C-212
//
//  @Author Zachary Reid and zrreid
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

import java.util.*;

public class Surgery extends Activity {
	private final String PATIENT;
	private ArrayList<String> doctors;
	private String operationType;
	private String notes;
	
	//Constructor
	public Surgery(String patientID, String operationType, String date, String roomNumber) {
		super("Sy", date, roomNumber);
		this.PATIENT = patientID;
		doctors = new ArrayList<>();
		this.operationType = operationType;
		this.notes = "";
	}
	//Returns the patient
	public String getPatient() { return this.PATIENT; }
	
	//Adds doctors to the surgical team
	public void addDoctors(String doctorID) { this.doctors.add(doctorID); }
	
	//Returns the doctors working the surgery
	public ArrayList<String> getDoctors() { return this.doctors; }
	
	//Sets the type of operation
	public void setOperationType(String type) { this.operationType = type; }
	
	//Returns the type of operation
	public String getOperationType() { return this.operationType; }
	
	//Adds notes to the surgery's notes
	public void addNotes(String notes) { this.notes += "\n" + notes; }
	
	//Returns the notes
	public String getNotes() { return this.notes; }
	
	//Overrides the toString method to produce better output
	public String toString() {
		String value = "";
		value += "ActivityID: " + this.getActivity();
		value += "\nPatient: " + this.PATIENT;
		value += "\nDoctors: ";
		for(String doc : doctors) { value += doc + ", "; }
		value = value.substring(0, value.length() - 2);
		value += "\nDate: " + this.getDate();
		value += "\nRoom Number: " + this.roomNumber;
		value += "\nOperation Type: " + this.operationType;
		value += "\nNotes:\n" + this.notes;
		return value;
	}
	
	//Test Client
	public static void main(String[] args) {
		Surgery test = new Surgery("Pt000001", "Brain Surgery", "04/26/2019", "R103");
		test.addDoctors("Dr000001");
		test.getRoomNumber();
		System.out.print(test.getRoomNumber());
	}
}
