package System;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SystemTests {

	@Test
	void test() {
		Appointment test = new Appointment("Pt000001", "Dr000001", "04/26/2019", "Physical", "R101", "Patient complained too much.");
		Time time1 = new Time(5,30);
		Time time2 = new Time(13,0);
		Time time3 = new Time(13,30);
		Time time4 = new Time(14,0);
		Date date1 = new Date(5,3,2019);
		Surgery surg1= new Surgery("Pt000001", "Brain Surgery", "04/26/2019", "R103");
		TimeBlock testBlock1 = new TimeBlock(time1, time3, test);
		
		
		//Testers for time class. Mainly the getters.
		assertEquals(time1.getHour(), 5);
		assertEquals(time1.getMinute(), 30);
		assertEquals(time3.getHour(), 13);
		assertEquals(time3.getMinute(), 30);
		
		
		//Testers for the appointment information getters.
		assertEquals(test.getRoomNumber(), "R101");
		assertEquals(test.getAppointmentType(), "Physical");
		assertEquals(test.getReasonForAppointment(), "Patient complained too much.");
		
		
		//Testers for dated getters.
		assertEquals(date1.getDay(),3);
		assertEquals(date1.getMonth(),5);
		assertEquals(date1.getYear(),2019);
		
		
		//Tester for checking time block is filled.
		assertEquals(testBlock1.isFilled(), true);
		
		
		//Tester for checking basic info about surgery.
		assertEquals(surg1.getOperationType(), "Brain Surgery");
		assertEquals(surg1.getRoomNumber(), "R103");
		
	}

}
