//  Final Project 
//
//	C-212
//
//  @Author Evan Brinckman and ebrinckm
//
//	Last edited: 4/12/2019
//
//////////////////////////////////////
package System;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class DoctorDatabase extends Database{
	
	private ArrayList<String> holder2= new ArrayList<String>();
	private ArrayList<DoctorProfile> dProf= new ArrayList<DoctorProfile>();
	DoctorProfile doc;

	public DoctorDatabase() throws FileNotFoundException {
		super("src\\\\DoctorProfiles");
		this.readDatabase();
	}
	
	/*public void FFbuildDatabase() {
		String username;
		String password;
		String type;
		String userID;
		String fName;
		String lName;
		String office;
		String pNumber;
		String email;
		String hours;
		File dir = new File(this.directoryName);
		File[] files = dir.listFiles();
		for(File f : files) {
			//Scanner reader = new Scanner(f);
			while(reader.hasNextLine()) {
				//Scanner lineReader 
			}
		}
	}*/
	
	public void readDatabase() throws FileNotFoundException {
		File dir = new File(this.directoryName);
		File[] files = dir.listFiles();
		for(File f : files) {
			BufferedReader reader = new BufferedReader(new FileReader(f));
			String[] holder;
				try {
					String line;
					while ((line = reader.readLine()) != null) {
						holder = line.split(" ");
						this.holder2.add(holder[1]);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		
		//TO DO: builds data base from file
	
	public void buildDatabase() {
		Credential cred =  new Credential(this.holder2.get(0), this.holder2.get(1), "Dr", this.holder2.get(3));
		String ID = "Dr";
		String inputfile = this.holder2.get(4) + this.holder2.get(5);
		String type = this.holder2.get(2);
		String fName = this.holder2.get(4);
		String lName = this.holder2.get(5);
		String spec = this.holder2.get(6);
		String office = this.holder2.get(7);
		String number = this.holder2.get(8);
		String email = this.holder2.get(9);
		String hours = this.holder2.get(10);
		this.doc = new DoctorProfile(cred,ID,fName,lName,inputfile,number,email,spec,office,hours);
		super.addElement(this.doc);
		this.dProf.add(this.doc);
		
	}
	
	public DoctorProfile getProfile(String name) {
		DoctorProfile found = null;
		//TO DO: Returns doctor profile based on search.
		for(DoctorProfile dr : this.dProf) {
			if (dr.getLastName().equals(name)) {
				found = dr;
			}
		}
		return found;
	}

}
