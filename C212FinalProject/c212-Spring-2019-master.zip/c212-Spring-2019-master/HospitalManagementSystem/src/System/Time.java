//  Final Project
//
//	C-212
//
//  @Author Zachary Reid and zrreid
//
//	Last edited: 4/16/2019
//
//////////////////////////////////////
package System;

public class Time implements Comparable<Time> {
	private final int HOUR;
	private final int MINUTE;
	
	//Uses military time
	//Constructor
	public Time(int hour, int minute) {
		this.HOUR = hour;
		this.MINUTE = minute;
	}
	
	//Constructor
	public Time(String time) {
		this.HOUR = Integer.parseInt(time.substring(0,2));
		this.MINUTE = Integer.parseInt(time.substring(3));
	}
	
	//Returns the time object's hour
	public int getHour() { return this.HOUR; }
	
	//Returns the time object's minute
	public int getMinute() { return this.MINUTE; }
	
	//Returns the difference between another time and itself
	public Time getDifference(Time other) {
		int hourDif; int minDif;
		if(other.getHour() >= this.HOUR) { hourDif = other.getHour() - this.HOUR; }
		else { hourDif = Math.abs(other.getHour() - this.HOUR); }
		if(other.getMinute() >= this.MINUTE) { minDif = other.getMinute() - this.MINUTE; }
		else { minDif = 60 + (other.getMinute() - this.MINUTE); hourDif--; }
		return new Time(hourDif, minDif);
	}
	
	//Returns the standard form of the time object
	public String getStandard() {
		if(this.HOUR > 12) { return (this.HOUR - 12) + ":" + this.MINUTE + "pm"; }
		else { return this.HOUR + ":" + this.MINUTE + "am"; }
	}
	
	//Overrides the toString method so that the output is more readable
	public String toString() {
		String time = "";
		if(this.HOUR < 10) { time += "0" + this.HOUR + ":"; }
		else { time += this.HOUR + ":"; }
		if(this.MINUTE < 10) { time += "0" + this.MINUTE; }
		else { time += this.MINUTE; }
		return time;
	}
	
	//Compares itself to another time object
	public int compareTo(Time other) {
		if(this.HOUR > other.getHour()) { return 1; }
		else if(this.HOUR < other.getHour()) { return -1; }
		else {
			if(this.MINUTE > other.getMinute()) { return 1; }
			else if(this.MINUTE < other.getMinute()) { return -1; }
			else { return 0; }
		}
	}
	
	//Test Client
	public static void main(String[] args) {
		Time test1 = new Time(13,30);
		Time test2 = new Time("09:43");
		System.out.println(test1.getHour());
		System.out.println(test1.getMinute());
		System.out.println(test1);
		System.out.println(test2);
		System.out.println(test1.getStandard());
		System.out.println(test1.compareTo(test2));
		System.out.println(test1.compareTo(test1));
	}
}
