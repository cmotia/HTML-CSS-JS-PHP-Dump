//  Final Project 
//
//	C-212
//
//  @Author Zachary Reid and zrreid
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

import java.io.*;

public class SampleFileGenerator {
	
	public static class SampleCred {
		private static int pNum = 1;
		private static int dNum = 1;
		private static int aNum = 0;
		private String username;
		private String password;
		private String type;
		private String userID;
		
		public SampleCred(String username, String password, String type, String ID) {
			this.username = username; this.password = password; this.type = type;
			if(ID.equals("Pt")) { this.userID = String.format(ID + "%08d", ++pNum); }
			else if(ID.equals("Dr")) { this.userID = String.format(ID + "%08d", ++dNum); }
			else { this.userID = String.format(ID + "%08d", ++aNum); }
		}
		public String toString() {
			String value = "";
			value += "Username: " + this.username;
			value += "\nPassword: " + this.password;
			value += "\nType: " + this.type;
			value += "\nUserID: " + this.userID;
			value += "\n$";
			return value;
		}
	}
	
	public static class SamplePatient {
		private static int num = 1;
		private String prefix = "Pt";
		private String username;
		private String password;
		private String type;
		private String userID;
		private String fName;
		private String lName;
		private String pNumber;
		private String email;
		
		public SamplePatient() {
			this.username = String.format("Pt" + "%08d", ++num);
			this.password = "password";
			this.type = "Patient";
			this.userID = String.format(prefix + "%08d", num);
			this.fName = "Pt" + num;
			this.lName = "Pt" + num;
			this.pNumber = "(###)###-####";
			this.email = "me@meh.com";
		}
		public String getUsername() { return this.username; }
		public String getPassword() { return this.password; }
		public String getType() { return this.type; }
		public String toString() {
			String value = "";
			value += "Username: " + this.username;
			value += "\nPassword: " + this.password;
			value += "\nUserID: " + this.userID;
			value += "\nType: " + this.type;
			value += "\nFirstName: " + this.fName;
			value += "\nLastName: " + this.lName;
			value += "\nPhoneNumber: " + this.pNumber;
			value += "\nEmail: " + this.email;
			return value;
		}
	}
	
	public static class SampleDoctor {
		private static int num = 1;
		private String prefix = "Dr";
		private String username;
		private String password;
		private String type;
		private String userID;
		private String fName;
		private String lName;
		private String specialty;
		private String office;
		private String pNumber;
		private String email;
		private String hours;
		
		public SampleDoctor() {
			this.username = String.format("Dr" + "%08d", ++num);
			this.password = "password";
			this.type = "Doctor";
			this.userID = String.format(prefix + "%08d", num);
			this.fName = "Dr" + num;
			this.lName = "Dr" + num;
			this.specialty = "Something";
			this.office = String.format("B2" + "%02d", num);
			this.pNumber = "(###)###-####";
			this.email = "me@meh.com";
			this.hours = "08:00/17:00";
		}
		public String getUsername() { return this.username; }
		public String getPassword() { return this.password; }
		public String getType() { return this.type; }
		public String toString() {
			String value = "";
			value += "Username: " + this.username;
			value += "\nPassword: " + this.password;
			value += "\nType: " + this.type;
			value += "\nFirstName: " + this.fName;
			value += "\nLastName: " + this.lName;
			value += "\nSpecialty: " + this.specialty;
			value += "\nOffice: " + this.office;
			value += "\nPhoneNumber: " + this.pNumber;
			value += "\nEmail: " + this.email;
			value += "\nHours: " + this.hours;
			return value;
		}
	}
	
	public static class SampleAssistant {
		private static int num = 0;
		private String prefix = "At";
		private String username;
		private String password;
		private String type;
		private String userID;
		private String fName;
		private String lName;
		private String office;
		private String pNumber;
		private String email;
		private String hours;
		
		public SampleAssistant() {
			this.username = String.format("At" + "%08d", ++num);
			this.password = "password";
			this.type = "Assistant";
			this.userID = String.format(prefix + "%08d", num);
			this.fName = "At" + num;
			this.lName = "At" + num;
			this.office = String.format("B2" + "%02d", num);
			this.pNumber = "(###)###-####";
			this.email = "me@meh.com";
			this.hours = "08:00/17:00";
		}
		public String getUsername() { return this.username; }
		public String getPassword() { return this.password; }
		public String getType() { return this.type; }
		public String toString() {
			String value = "";
			value += "Username: " + this.username;
			value += "\nPassword: " + this.password;
			value += "\nType: " + this.type;
			value += "\nUserID: " + this.userID;
			value += "\nFirstName: " + this.fName;
			value += "\nLastName: " + this.lName;
			value += "\nOffice: " + this.office;
			value += "\nPhoneNumber: " + this.pNumber;
			value += "\nEmail: " + this.email;
			value += "\nHours: " + this.hours;
			return value;
		}
	}
	public static void main(String[] args) throws FileNotFoundException {
		String credDir = "src\\CredentialsFile";
		String drDir = "src\\DoctorProfiles";
		String atDir = "src\\AssistantProfiles";
		String ptDir = "src\\PatientProfiles";
		String ext = ".txt";
		
		File dir = new File(drDir);
		File[] files = dir.listFiles();
		for(File f : files) { System.out.println(f); }
		
		
		String Top = "Username: tramen\nPassword: soupnazi\nType: Doctor\nUserID: Dr000001\n$";
		String John = "Username: jdoe\nPassword: coolguy12\nType: Patient\nUserID: Pt000001\n$";
		PrintWriter credWriter = new PrintWriter(credDir + "\\" + "Credentials.txt");
		credWriter.println(Top);
		credWriter.println(John);
		
		for(int i = 0; i < 3; i++) {
			SampleDoctor doc = new SampleDoctor();
			String docFile = drDir + "\\" + doc.getUsername() + ext;
			SampleCred cred = new SampleCred(doc.getUsername(), doc.getPassword(), doc.getType(), "Dr");
			PrintWriter docWriter = new PrintWriter(docFile);
			docWriter.print(doc);
			credWriter.println(cred);
			docWriter.close();			
		}
		
		for(int j = 0; j < 3; j++) {
			SamplePatient pat = new SamplePatient();
			String patFile = ptDir + "\\" + pat.getUsername() + ext;
			SampleCred cred = new SampleCred(pat.getUsername(), pat.getPassword(), pat.getType(), "Pt");
			PrintWriter patWriter = new PrintWriter(patFile);
			patWriter.print(pat);
			credWriter.println(cred);
			patWriter.close();
		}
		
		for(int j = 0; j < 3; j++) {
			SampleAssistant ast = new SampleAssistant();
			String astFile = atDir + "\\" + ast.getUsername() + ext;
			SampleCred cred = new SampleCred(ast.getUsername(), ast.getPassword(), ast.getType(), "At");
			PrintWriter astWriter = new PrintWriter(astFile);
			astWriter.print(ast);
			credWriter.println(cred);
			astWriter.close();
		}
		
		credWriter.close();
		
		
		
	}
}
