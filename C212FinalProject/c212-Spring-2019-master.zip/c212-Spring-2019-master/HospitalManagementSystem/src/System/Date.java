//  Final Project
//
//	C-212
//
//  @Author Zachary Reid and zrreid
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

public class Date implements Comparable<Date> {
	private final int MONTH;
	private final int DAY;
	private final int YEAR;
	
	//Constructor
	public Date(int month, int day, int year) {
		this.MONTH = month;
		this.DAY = day;
		this.YEAR = year;
	}
	
	//Constructor
	public Date(String date) {
		this.MONTH = Integer.parseInt(date.substring(0, 2));
		this.DAY = Integer.parseInt(date.substring(3,5));
		this.YEAR = Integer.parseInt(date.substring(6));
	}
	
	//Returns the date's month
	public int getMonth() { return this.MONTH; }
	
	//Returns the date's day
	public int getDay() { return this.DAY; }
	
	//Returns the date's year
	public int getYear() { return this.YEAR; }

	//Compares the date to another date object
	public int compareTo(Date other) {
		if(this.YEAR < other.getYear()) { return -1; }
		else if(this.YEAR > other.getYear()) { return 1; }
		else {
			if(this.MONTH < other.getMonth()) { return -1; }
			else if(this.MONTH > other.getMonth()) { return 1; }
			else {
				if(this.DAY < other.getDay()) { return -1; }
				else if(this.DAY > other.getDay()) { return 1; }
				else { return 0; }
			}
		}
	}
	
	//Overrides the toString method to make printing easier
	public String toString() {
		String date = "";
		if(this.MONTH < 10) { date += "0" + this.MONTH + "/"; }
		else { date += this.MONTH + "/"; }
		if(this.DAY < 10) { date += "0" + this.DAY + "/"; }
		else { date += this.DAY + "/"; }
		date += this.YEAR;
		return date;
	}
	
	//Test Client
	public static void main(String[] args) {
		Date test1 = new Date(5,3,2019);
		Date test2 = new Date(5,17,2019);
		System.out.println(test1.getMonth());
		System.out.println(test1.getDay());
		System.out.println(test1.getYear());
		System.out.println(test1);
		System.out.println(test2);
		System.out.println(test1.compareTo(test2));
	}
}
