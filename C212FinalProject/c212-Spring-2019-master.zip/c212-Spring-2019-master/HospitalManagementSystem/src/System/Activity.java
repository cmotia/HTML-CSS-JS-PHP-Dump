//  Final Project
//
//	C-212
//
//  @Author Zachary Reid and zrreid
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

public class Activity {
	protected static int activityNumber = 0;
	protected final String ACTIVITY;
	protected Date date;
	protected String roomNumber;
	
	//Constructor
	public Activity(String activityID, String date, String roomNumber) {
		this.ACTIVITY = String.format(activityID + "%08d", ++activityNumber);
		this.date = new Date(date);
		this.roomNumber = roomNumber;
	}
	
	//Returns the activityID of the Activity
	public String getActivity() { return this.ACTIVITY; }
	
	//Sets the activity's date
	public void setDate(String newDate) { this.date = new Date(newDate); }
	
	//Returns the activity's date
	public Date getDate() { return this.date; }
	
	//Sets the activity's room number
	public void setLocation(String newRoomNumber) { this.roomNumber = newRoomNumber; }
	
	//Returns the room number of the activity
	public String getRoomNumber() { return this.roomNumber; }
	
	//Returns the activity's type
	public String getActivityType() {
		if(this.ACTIVITY.substring(0,2).toLowerCase() == "ap") { return "Appointment"; }
		else if(this.ACTIVITY.substring(0,2).toLowerCase() == "sm") { return "StaffMeeting"; }
		else if(this.ACTIVITY.substring(0,2).toLowerCase() == "sy") { return "Surgery"; }
		else { return ""; }
	}
}
