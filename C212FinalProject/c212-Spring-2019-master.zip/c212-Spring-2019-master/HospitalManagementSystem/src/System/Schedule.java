//  Final Project
//
//	C-212
//
//  @Author Zachary Reid and zrreid
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

import java.util.*;

public class Schedule {
	private final HashMap<String, DailySchedule> SCHEDULE;
	
	//Constructor
	public Schedule(Time start, Time end) {
		this.SCHEDULE = new HashMap<>();
		this.SCHEDULE.put("Monday", new DailySchedule(start, end));
		this.SCHEDULE.put("Tuesday", new DailySchedule(start, end));
		this.SCHEDULE.put("Wednesday", new DailySchedule(start, end));
		this.SCHEDULE.put("Thursday", new DailySchedule(start, end));
		this.SCHEDULE.put("Friday", new DailySchedule(start, end));
		this.SCHEDULE.put("Saturday", new DailySchedule(start, end));
		this.SCHEDULE.put("Sunday", new DailySchedule(start, end));
	}
	
	//Returns the schedule
	public HashMap<String, DailySchedule> getSchedule() { return this.SCHEDULE; }
	
	//Adds an activity to a timeblock and adds it to the Schedule's TreeSet with the key of the specific day
	public boolean addActivity(String day, Time start, Time end, Activity activity) {
		return this.SCHEDULE.get(day).addActivity(start, end, activity);
	}
	
	//Returns the a specific day in the schedule
	public DailySchedule getDailySchedule(String day) { return this.SCHEDULE.get(day); }
	
	//Cancels an activity on a specific day and turns the surrounding empty timeblocks into one large timeblock
	public boolean cancelActivity(String day, String activityID) {
		return this.SCHEDULE.get(day).removeActivity(activityID);
	}
	
	//Test Client
	public static void main(String[] args) {
		Schedule test = new Schedule(new Time(5,0), new Time(20,0));
		System.out.println(test.getDailySchedule("Monday"));
		Appointment testAp = new Appointment("Pt000001", "Dr000001", "04/26/2019", "Physical", "R101", "Patient complained too much.");
		test.addActivity("Monday", new Time(13,0), new Time(14,0), testAp);
	}
}
