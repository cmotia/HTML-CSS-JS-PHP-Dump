//  Final Project
//
//	C-212
//
//  @Author Zachary Reid and zrreid
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

import java.util.PriorityQueue;

public class DailySchedule extends PriorityQueue<TimeBlock> {
	private Time start;
	private Time end;
	
	//Default Constructor
	public DailySchedule() {  }
	
	//Constructor
	public DailySchedule(Time start, Time end) {
		this.start = start;
		this.end = end;
		int sHr = start.getHour();
		int eHr = end.getHour();
		int blockNum = eHr - sHr;
		for(int i = 0; i < blockNum; i++) {
			Time time1 = new Time(sHr, 0);
			Time time2 = new Time(sHr + 1, 0);
			TimeBlock block = new TimeBlock(time1, time2);
			this.add(block);
			++sHr;
			if(sHr == eHr) { break; }
		}
	}
	
	//Adds timeblock to the dailyschedule
	public boolean addActivity(Time start, Time end, Activity activity) {
		TimeBlock block = new TimeBlock(start, end, activity);
		DailySchedule tempSched = new DailySchedule();
		TimeBlock temp;
		while(!this.isEmpty()) {
			temp = this.poll();
			if(block.compareTo(temp) == 0) {
				if(!temp.isFilled()) { tempSched.add(block); }
				else { return false; }				
			}
			else { tempSched.add(temp); }
		}
		
		while(!tempSched.isEmpty()) { this.add(tempSched.poll()); }
		return true;
	}
	
	//Removes an activity from the daily schedule
	public boolean removeActivity(String activityID) {
		DailySchedule temp = new DailySchedule();
		boolean success = false;
		TimeBlock block;
		while(!this.isEmpty()) {
			block = this.poll();
			if(block.getActivityID().equals(activityID)) { block.reset(); success = true; }
			temp.add(block);
		}
		while(!temp.isEmpty()) { this.add(temp.poll()); }
		
		return success;
	}
	
	//Overrides the toString method to produce better output
	public String toString() {
		String value = "Daily Schedule = [ ";
		
		PriorityQueue<TimeBlock> newQueue = new PriorityQueue<>();
		TimeBlock temp;
		while(!this.isEmpty()) {
			temp = this.poll();
			value += temp.toString() + ", ";
			newQueue.add(temp);
		}
		
		while(!newQueue.isEmpty()) { this.add(newQueue.poll()); }
		value = value.substring(0,value.length()-2) + " ]";
		return value;
	}
	
	//Test Client
	public static void main(String[] args) {
		Time time1 = new Time(5,0);
		Time time2 = new Time(18,0);
		TimeBlock block1 = new TimeBlock(time1, time2);
		DailySchedule test = new DailySchedule(time1, time2);
		System.out.println(test);
		Appointment testAp = new Appointment("Pt000001", "Dr000001", "04/26/2019", "Physical", "R101", "Patient complained too much.");
		test.addActivity(new Time(6,0), new Time(7,0), testAp);
		System.out.println(test);
		
	}
}
