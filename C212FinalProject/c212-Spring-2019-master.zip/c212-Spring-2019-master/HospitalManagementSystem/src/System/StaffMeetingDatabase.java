package System;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

//  Final Project 
//
//	C-212
//
//  @Author Evan Brinckman and ebrinckm
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
public class StaffMeetingDatabase extends Database{
	
	private ArrayList<String> holder2= new ArrayList<String>();
	private ArrayList<StaffMeeting> staffML= new ArrayList<StaffMeeting>();
	private StaffMeeting staffM;

	public StaffMeetingDatabase() throws FileNotFoundException {
		super("src\\StaffMeeting");
		this.readDatabase();
	}
	
	public void readDatabase() throws FileNotFoundException {
		File dir = new File(this.directoryName);
		File[] files = dir.listFiles();
		for(File f : files) {
			BufferedReader reader = new BufferedReader(new FileReader(f));
			String[] holder;
				try {
					String line;
					while ((line = reader.readLine()) != null) {
						holder = line.split(" ");
						this.holder2.add(holder[1]);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	
	public void buildDatabase() {
		String topic = this.holder2.get(0);
		String date = this.holder2.get(1);
		String roomNumber = this.holder2.get(2);
		this.staffM = new StaffMeeting(topic,date,roomNumber);
		super.addAct(this.staffM);
		this.staffML.add(this.staffM);
	}
}
