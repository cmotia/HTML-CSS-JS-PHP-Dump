//  Final Project 
//
//	C-212
//
//  @Author Evan Brinckman and ebrinckm
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class SurgeryDatabase extends Database{
	
	private ArrayList<String> holder2= new ArrayList<String>();
	private ArrayList<Surgery> surgL= new ArrayList<Surgery>();
	private Surgery surg;
	
	public SurgeryDatabase() throws FileNotFoundException {
		super("src\\Surgery");
		this.readDatabase();
	}
	
	public void readDatabase() throws FileNotFoundException {
		File dir = new File(this.directoryName);
		File[] files = dir.listFiles();
		for(File f : files) {
			BufferedReader reader = new BufferedReader(new FileReader(f));
			String[] holder;
				try {
					String line;
					while ((line = reader.readLine()) != null) {
						holder = line.split(" ");
						this.holder2.add(holder[1]);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	
	public void buildDatabase() {
		String patientID = this.holder2.get(0);
		String operationType = this.holder2.get(1);
		String date = this.holder2.get(2);
		String roomNumber = this.holder2.get(3);
		this.surg = new Surgery(patientID,operationType,date,roomNumber);
		super.addAct(this.surg);
		this.surgL.add(this.surg);
	}

}
