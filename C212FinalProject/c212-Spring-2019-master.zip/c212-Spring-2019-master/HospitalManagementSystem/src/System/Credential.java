//  Final Project 
//
//	C-212
//
//  @Author <first name last name> and <username>
//
//	Last edited: 4/12/2019
//
//////////////////////////////////////
package System;

public class Credential {
	
	private final String username;
	private String password;
	private final String type;
	private final String userID;
	
	public Credential(String user, String pass, String type, String userID) {
		this.username = user;
		setPassword(pass);
		this.type = type;
		this.userID = userID;
		
	}
	
	public String getUsername() {
		return username;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getType() {
		return type;
	}

	public String getUserID() {
		return userID;
	}

}
