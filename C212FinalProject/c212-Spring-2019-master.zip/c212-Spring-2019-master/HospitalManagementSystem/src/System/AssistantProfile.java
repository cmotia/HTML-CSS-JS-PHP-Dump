//  Final Project 
//
//	C-212
//
//  @Author Christopher Motia and cmotia
//
//	Last edited: 4/12/2019
//
//////////////////////////////////////
package System;

import java.util.HashMap;

public class AssistantProfile extends Profile {
    private final static String PROFILE_TYPE = "Assistant";
    private String office;
    private String hours;

    public AssistantProfile(Credential credential, String ID, String fName, String lName, String inputFile, String phoneNumber, String email, String office) {
        super(credential, ID, fName, lName, PROFILE_TYPE, inputFile, phoneNumber, email);
        this.office = office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public String getProfileType() {
        return PROFILE_TYPE;
    }

    public String getOffice() {
        return office;
    }

    public void setHours (String hours) {
        this.hours=hours;
    }

    public String getHours() {
        return hours;
    }


    @java.lang.Override
    public java.lang.String toString() {
        return  "Username: " + this.getCREDENTIAL().getUsername() + '\n'+
                //gets username from credential
                "Password: " + this.getCREDENTIAL().getPassword() + '\n'+
                //gets password from credential
                "ProfileType: " + this.getPROFILE_TYPE() + '\n' +
                "UserID: " + this.getUserID() + '\n' +
                "FirstName: " +this.getFirstName() + '\n'+
                "LastName: " + this.getLastName() + '\n' +
                "Office: " + this.office + '\n' +
                "PhoneNumber: " + this.getPhoneNumber() + '\n'+
                "Email: " + this.getEmail() + '\n'+
                "hours: " + this.hours;
    }
}
