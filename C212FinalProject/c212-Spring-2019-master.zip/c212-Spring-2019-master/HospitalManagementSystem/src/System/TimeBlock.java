//  Final Project
//
//	C-212
//
//  @Author Zachary Reid and zrreid
//
//	Last edited: 4/26/2019
//
//////////////////////////////////////
package System;

public class TimeBlock implements Comparable<TimeBlock> {
	private Time startTime;
	private Time endTime;
	private Time duration;
	private boolean filled;
	private Activity activity;
	
	//Uses military time
	//Default constructor for a timeblock
	public TimeBlock(Time start, Time end) {
		this.startTime = start;
		this.endTime = end;
		this.duration = this.startTime.getDifference(this.endTime);
		this.filled = false;
		this.activity = null;
	}
	
	//Constructor for when an activity is assigned to the timeblock
	public TimeBlock(Time start, Time end, Activity activity) {
		this.startTime = start;
		this.endTime = end;
		this.duration = this.startTime.getDifference(this.endTime);
		this.filled = true;
		this.activity = activity;		
	}
	
	//Compares itself to another timeblock
	public int compareTo(TimeBlock other) {
		if(this.startTime.compareTo(other.getStartTime()) == -1) { return -1; }
		else if(this.startTime.compareTo(other.getStartTime()) == 0) { return 0; }
		else { return 1; }
	}
	
	//Compares its endtime to another timeblock's endtime
	public int compareEndTime(TimeBlock other) {
		if(this.endTime.compareTo(other.getEndTime()) == -1) { return -1; }
		else if(this.endTime.compareTo(other.getEndTime()) == 0) { return 0; }
		else { return 1; }
	}
	
	//Returns the timeblock's start time
	public Time getStartTime() { return this.startTime; }
	
	//Returns the timeblock's end time
	public Time getEndTime() { return this.endTime; }
	
	//Returns the duration
	public Time getDuration() { return this.duration; }
	
	//Returns whether the timeblock has been filled with an activity
	public boolean isFilled() { return this.filled; }
	
	//Sets the activity of the timeblock
	public void setActivity(Activity activity) { this.activity = activity; }
	
	//Returns the activityID that belongs to this timeblock's activity
	public String getActivityID() {
		if(isFilled()) { return this.activity.getActivity(); }
		else { return null; }
	}
	
	//Returns the activity that belongs to this timeblock
	public Activity getActivity() { return this.activity; }
	
	//Resets the timeblock to be reused later
	public void reset() {
		this.filled = false;
		this.activity = null;
	}
	
	//Returns a timeblock that is a combination of this timeblock and the parameter timeblock
	public TimeBlock condense(TimeBlock other) {
		if(this.compareTo(other) == -1) { return new TimeBlock(this.startTime,other.getEndTime()); }
		else { return new TimeBlock(other.startTime, this.getEndTime()); }		
	}
	
	//Returns whether a timeblock is bigger than this timeblock
	public boolean isBigger(TimeBlock other) {
		if(this.compareTo(other) == -1) {
			if(this.compareEndTime(other) == 1) { return true; }
			else { return false; }
		}
		else { return false; }
		
	}
	
	//Overrides the toString method of the object to produce better output
	public String toString() {
		String value = "";
		value += this.startTime + "-" + this.endTime;
		if(isFilled()) { value += " : " + this.getActivityID(); }
		return value;
	}
	
	//Test Client
	public static void main(String[] args) {
		Appointment testAp = new Appointment("Pt000001", "Dr000001", "04/26/2019", "Physical", "R101", "Patient complained too much.");
		Time time1 = new Time(13,0);
		Time time2 = new Time(13,30);
		Time time3 = new Time(14,0);
		Time time4 = new Time(15,0);
		TimeBlock testBlock1 = new TimeBlock(time1, time3, testAp);
		TimeBlock testBlock2 = new TimeBlock(time3, time4, testAp);
		TimeBlock testBlock3 = new TimeBlock(time2, time4, testAp);
		System.out.println(testBlock1);
		System.out.println(testBlock2);
		System.out.println(testBlock3);
		System.out.println(testBlock1.isFilled());
		System.out.println(testBlock2.isFilled());
		System.out.println(testBlock3.isFilled());
		System.out.println(testBlock1.getDuration());
	}
}