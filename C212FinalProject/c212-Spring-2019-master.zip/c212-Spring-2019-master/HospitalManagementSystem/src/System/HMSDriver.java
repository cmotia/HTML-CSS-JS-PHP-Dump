//  Final Project 
//
//	C-212
//
//  @Author Grant Handloser and gjhandlo
//
//	Last edited: 4/12/2019
//
//////////////////////////////////////
package System;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class HMSDriver {
	public enum SystemState { DOCTOR, ASSISTANT, PATIENT }
	private SystemState currentState;
	private Profile user;
	private final CredentialDatabase CREDENTIAL_DATABASE;
	private final DoctorDatabase DOCTOR_DATABASE;
	private final AssistantDatabase ASSISTANT_DATABASE;
	private final PatientDatabase PATIENT_DATABASE;
	//private final SurgeryDatabase SURGERY_DATABASE;
	//private final StaffMeetingDatabase STAFF_MEETING_DATABASE;
	//private final AppointmentDatabase APPOINTMENT_DATABASE;

	public HMSDriver() throws FileNotFoundException {
		CREDENTIAL_DATABASE = new CredentialDatabase();
		DOCTOR_DATABASE = new DoctorDatabase();
		ASSISTANT_DATABASE = new AssistantDatabase();
		PATIENT_DATABASE = new PatientDatabase();
		//SURGERY_DATABASE = new SurgeryDatabase();
		//STAFF_MEETING_DATABASE = new StaffMeetingDatabase();
		//APPOINTMENT_DATABASE = new AppointmentDatabase();

		loginProtocol();

		Boolean repeat = false;
		do {
		if(currentState == SystemState.DOCTOR) {
			doctorPerspective();
		} else if(currentState == SystemState.ASSISTANT) {
			assistantPerspective();
		} else {
			patientPerspective();
		}
		Scanner continueScan = new Scanner(System.in);
		System.out.println("Would you like to continue working? Enter yes or no: ");
		String answer = continueScan.next();
		if(answer.equals("yes")) {
			repeat = true;
		}
		} while (repeat);
		
		closeDatabases();
		
	}

	public void loginProtocol() {
		Scanner loginScan = new Scanner(System.in);
		System.out.print("Enter username: ");
		String username = loginScan.next();
		System.out.print("Enter password: ");
		String password = loginScan.next();
		System.out.print("Enter type (Dr, As, Pt): ");
		String type = loginScan.next();
		Credential loginCred;

		int loginState;

		do {

			loginCred  = new Credential(username, password, type, "");
			loginState = CREDENTIAL_DATABASE.verifyCredential(loginCred);

			if(loginState == 0) {
				System.out.println("This username does not exist, would you like to make a new account?");
				CREDENTIAL_DATABASE.addCred(loginCred);

				System.out.print("Enter your first name: ");
				String firstName = loginScan.next();
				System.out.print("Enter your last name: ");
				String lastName = loginScan.next();

				if(loginCred.getType().equals("Dr")) {
					DOCTOR_DATABASE.addElement(new DoctorProfile(loginCred, loginCred.getType(), firstName, lastName, firstName + lastName, "", "", "", "",""));
				} else if(loginCred.getType().equals("As")) {
					ASSISTANT_DATABASE.addElement(new AssistantProfile(loginCred, loginCred.getType(), firstName, lastName, firstName + lastName, "", "", ""));
				} else {
					PATIENT_DATABASE.addElement(new PatientProfile(loginCred, loginCred.getType(), firstName, lastName, firstName + lastName, "", ""));
				}

				loginState = 4;
			} else if(loginState == 1) {
				System.out.println("Successful login!");
				if(loginCred.getType().equals("Dr")) {
					currentState = SystemState.DOCTOR;
					user = DOCTOR_DATABASE.getProfile(loginCred.getUsername());
				} else if(loginCred.getType().equals("As")) {
					currentState = SystemState.ASSISTANT;
					user = ASSISTANT_DATABASE.getProfile(loginCred.getUsername());
				} else {
					currentState = SystemState.PATIENT;
					user = PATIENT_DATABASE.getProfile(loginCred.getUsername());
				}
			} else if(loginState == 2) {
				System.out.println("Incorrect password.");
				System.out.print("Please reenter password: ");
				password = loginScan.next();
			} else {
				System.out.println("Incorrect type.");
				System.out.print("Please reenter type: ");
				type = loginScan.next();
			}
		} while(loginState > 1);
	}

	public void closeDatabases() {
		CREDENTIAL_DATABASE.buildDatabase();
		DOCTOR_DATABASE.buildDatabase();
		ASSISTANT_DATABASE.buildDatabase();
		PATIENT_DATABASE.buildDatabase();
		/*SURGERY_DATABASE.buildDatabase();
		STAFF_MEETING_DATABASE.buildDatabase();
		APPOINTMENT_DATABASE.buildDatabase();*/
	}

	public void doctorPerspective() {
		if(user instanceof DoctorProfile) {
			Scanner perspectiveScan = new Scanner(System.in);
			System.out.println("Hello " +  user.getFirstName() + " " + user.getLastName() + "!");
			System.out.println("Enter 1 to add/update availability hours.");
			System.out.println("Enter 2 to add/update information.");
			System.out.println("Enter 3 to view personal schedule.");
			System.out.println("Enter 4 to view appointments.");
			System.out.println("Enter 5 to view patient history and other details.");
			System.out.print("Please enter a number: ");
			int selection = perspectiveScan.nextInt();

			if(selection == 1) {
				System.out.println("Current availability: " + ((DoctorProfile) user).getHours());
				for(Profile d : DOCTOR_DATABASE.getElements()) {
					if(d.getCREDENTIAL().getUsername().equals(user.getCREDENTIAL().getUsername())) {
							System.out.print("Enter 1 to update availability");
							if(perspectiveScan.nextInt() == 1) {
								System.out.print("Enter new availability: ");
								((DoctorProfile) d).setHours(perspectiveScan.next());
							}
					}
				}
			} else if(selection == 2) {
				System.out.println("Current phone number: " + user.getPhoneNumber());
				System.out.println("Current email: " + user.getEmail());
				System.out.println("Current specialty: " + ((DoctorProfile) user).getSpecialty());
				System.out.println("Current office: " + ((DoctorProfile) user).getOffice());
				for(Profile d : DOCTOR_DATABASE.getElements()) {
					if(d.getCREDENTIAL().getUsername().equals(user.getCREDENTIAL().getUsername())) {
						if(d instanceof DoctorProfile) {
							System.out.println("Enter 1 to update phone number.");
							System.out.println("Enter 2 to update email.");
							System.out.println("Enter 3 to update specialty.");
							System.out.println("Enter 4 to update office.");
							System.out.print("Please enter a number: ");
							int update = perspectiveScan.nextInt();
							
							if(update == 1) {
								System.out.print("Enter a new phone number: ");
								d.setPhoneNumber(perspectiveScan.next());
							} else if(update == 2) {
								System.out.print("Enter a new email: ");
								d.setEmail(perspectiveScan.next());
							} else if(update == 3) {
								System.out.print("Enter a new specialty: ");
								((DoctorProfile) d).setSpecialty(perspectiveScan.next());
							} else if(update == 4) {
								System.out.print("Enter a new office: ");
								((DoctorProfile) d).setOffice(perspectiveScan.next());
							}
						}
					}
				}
			} else if(selection == 3) {
				System.out.print("Please enter a day of the week: ");
				String day = perspectiveScan.next();
				System.out.println(((DoctorProfile) user).getSchedule().getDailySchedule(day));
			} else if(selection == 4) {
				/*for(Appointment a : APPOINTMENT_DATABASE.getAppt()) {
					if(a.getDoctor().contentEquals(user.getID())) {
						System.out.println(a.toString());
					}
				}*/
			} else if(selection == 5) {
				System.out.print("Enter the desired patient's last name: ");
				Scanner patientScan = new Scanner(System.in);
				String desiredPatient = patientScan.next();
				for(Profile p : PATIENT_DATABASE.getElements()) {
					if(p.getLastName().equals(desiredPatient)) {
						if(p instanceof PatientProfile) {
							System.out.println("Patient history:");
							for(Appointment a : ((PatientProfile) p).getAppointmentHistory()) {
								System.out.println(a.toString());
							}
						}
					}
				}
			}

		}

	}

	public void assistantPerspective() {
		if(user instanceof AssistantProfile) {
			Scanner perspectiveScan = new Scanner(System.in);
			System.out.println("Hello " +  user.getFirstName() + " " + user.getLastName() + "!");
			System.out.println("Enter 1 to add doctors' appointments.");
			System.out.println("Enter 2 to add/update doctors' information.");
			System.out.println("Enter 3 to add/update/view patients' information and past history.");
			System.out.println("Enter 4 to approve appointments.");
			System.out.println("Enter 5 to view past appointments.");
			System.out.print("Please enter a number: ");
			int selection = perspectiveScan.nextInt();

			if(selection == 1) {
				System.out.print("Enter the desired doctor's last name: ");
				String desiredDoctor = perspectiveScan.next();
				for(Profile d : DOCTOR_DATABASE.getElements()) {
					/*if(d.getLastName().equals(desiredDoctor)) {
				APPOINTMENT_DATABASE.addAct(new Appointment("", d.getID(), "", "", "", ""));
				}*/
				}
			} else if(selection == 2) {
				for(Profile d : DOCTOR_DATABASE.getElements()) {
					System.out.println("Doctors:");
					if(d instanceof DoctorProfile) {
						System.out.println(d.getFirstName() + d.getLastName());
					}
				}
				System.out.print("Enter the desired doctor's last name: ");
				String desiredDoctor = perspectiveScan.next();
				for(Profile d : DOCTOR_DATABASE.getElements()) {
					if(d.getLastName().equals(desiredDoctor)) {
						if(d instanceof DoctorProfile) {
							System.out.println("Name: " + d.getFirstName() + d.getLastName());
							System.out.println("Phone number: " + d.getPhoneNumber());
							System.out.println("Email: " + d.getEmail());
							System.out.println("Specialty: " + ((DoctorProfile) d).getSpecialty());
							System.out.println("Office : " + ((DoctorProfile) d).getOffice());
							System.out.println("Availability: " + ((DoctorProfile) d).getHours());
							
							System.out.println("Enter 1 to update phone number.");
							System.out.println("Enter 2 to update email.");
							System.out.println("Enter 3 to update specialty.");
							System.out.println("Enter 4 to update office.");
							System.out.print("Please enter a number: ");
							int update = perspectiveScan.nextInt();
							
							if(update == 1) {
								System.out.print("Enter a new phone number: ");
								d.setPhoneNumber(perspectiveScan.next());
							} else if(update == 2) {
								System.out.print("Enter a new email: ");
								d.setEmail(perspectiveScan.next());
							} else if(update == 3) {
								System.out.print("Enter a new specialty: ");
								((DoctorProfile) d).setSpecialty(perspectiveScan.next());
							} else if(update == 4) {
								System.out.print("Enter a new office: ");
								((DoctorProfile) d).setOffice(perspectiveScan.next());
							}
						}
					}
				}
			} else if(selection == 3) {
				System.out.print("Enter the desired patient's last name: ");
				String desiredPatient = perspectiveScan.next();
				for(Profile p : PATIENT_DATABASE.getElements()) {
					if(p.getLastName().equals(desiredPatient)) {
						if(p instanceof PatientProfile) {
							System.out.println("Name: " + p.getFirstName() + p.getLastName());
							System.out.println("Phone number: " + p.getPhoneNumber());
							System.out.println("Email: " + p.getEmail());
							System.out.println("Appointments: ");
							for(Appointment a : ((PatientProfile) p).getAppointmentHistory()) {
								System.out.println(a.toString());
							}
							
							System.out.println("Enter 1 to update phone number.");
							System.out.println("Enter 2 to update email.");
							System.out.print("Please enter a number: ");
							int update = perspectiveScan.nextInt();
							
							if(update == 1) {
								System.out.print("Enter a new phone number: ");
								p.setPhoneNumber(perspectiveScan.next());
							} else if(update == 2) {
								System.out.print("Enter a new email: ");
								p.setEmail(perspectiveScan.next());
							}
							
						}
					}
				}
			} else if(selection == 4) {
				System.out.print("Enter appointment ID: ");
				String appointment = perspectiveScan.next();
				/*for(Appointment a : APPOINTMENT_DATABASE.getAppt()) {
					if(appointment.contentEquals(a.getActivity())) {
						a.addNotes("APPROVED");
					}
				}*/
			} else if(selection == 5) {
				System.out.print("Please enter the month: ");
				int month = perspectiveScan.nextInt();
				System.out.println("Please enter the day: ");
				int day = perspectiveScan.nextInt();
				System.out.println("Please enter the year: ");
				int year = perspectiveScan.nextInt();
				Date today = new Date(month, day, year);
				
				/*for(Appointment a : APPOINTMENT_DATABASE.getAppt()) {
					System.out.println("Past appointments: ");
					if(a.getDate().compareTo(today) == -1) {
						System.out.println(a.toString());
					}
				}*/
			}

		}

	}

	public void patientPerspective() {
		if(user instanceof PatientProfile) {
			Scanner perspectiveScan = new Scanner(System.in);
			System.out.println("Hello " +  user.getFirstName() + " " + user.getLastName() + "!");
			System.out.println("Enter 1 to view all doctors and their information.");
			System.out.println("Enter 2 to request to schedule/reschedule an appointment.");
			System.out.println("Enter 3 to cancel an appointment.");
			System.out.println("Enter 4 to view view information related to past visits.");
			System.out.print("Please enter a number: ");
			int selection = perspectiveScan.nextInt();

			if(selection == 1) {
				for(Profile d : DOCTOR_DATABASE.getElements()) {
					if(d instanceof DoctorProfile) {
						System.out.println("Doctor name: " + d.getFirstName() + d.getLastName());
						System.out.println("Phone number: " + d.getPhoneNumber());
						System.out.println("Email: " + d.getEmail());
						System.out.println("Specialty: " + ((DoctorProfile) d).getSpecialty());
						System.out.println("Office: " + ((DoctorProfile) d).getOffice());
						System.out.println("Availability" + ((DoctorProfile) d).getHours());
					}
				}
			} else if(selection == 2) {
				System.out.print("Enter appointment ID: ");
				String appointment = perspectiveScan.next();
				/*for(Appointment a : APPOINTMENT_DATABASE.getAppt()) {
					if(appointment.contentEquals(a.getActivity())) {
						System.out.print("Please enter the month for appointment: ");
						int month = perspectiveScan.nextInt();
						System.out.println("Please enter the day for appointment: ");
						int day = perspectiveScan.nextInt();
						System.out.println("Please enter the year for appointment: ");
						int year = perspectiveScan.nextInt();
						a.setDate(new Date(month, day, year).toString());
						a.addNotes("PENDING");
					}
				}*/
			} else if(selection == 3) {
				System.out.print("Enter appointment ID: ");
				String appointment = perspectiveScan.next();
				/*for(Appointment a : APPOINTMENT_DATABASE.getAppt()) {
					if(appointment.contentEquals(a.getActivity())) {
						a.addNotes("CANCELLED");
					}
				}*/
			} else if(selection == 4) {
				if(user instanceof PatientProfile) {
					System.out.println("Past visits: ");
					for(Appointment a : ((PatientProfile) user).getAppointmentHistory()) {
						System.out.println(a.toString());
					}
				}
			} 

		}

	}

	public static void main(String args[]) throws FileNotFoundException {
		new HMSDriver();
	}
}

