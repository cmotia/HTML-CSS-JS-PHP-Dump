﻿Hello and thank you for using our software
In order to use our program you will first


Open the Java class “HMSDriver”


You will be prompted to enter a 
1. Username
2. Password
3. Type
If entered correctly you will be taken to a selection menu based on the type of credential entered


If username is a new username you will be prompted to create a new account.
If password is incorrect you will be prompted to reenter your password. 
If type does not match an account you will be prompted to re enter type. 
Doctors can
1. Update and add hours
2. Update information
3. View their schedule
4. View appointments
5. View patient history
By selecting the options prompted of them




Assistants can 
1. Update doctors appointments
2. Update doctor information
3. Update and view patient information 
4. Approve appointments 
5. View past appointments
Using prompted messages 


Patients can
1. View all doctors and their information
2. Request to schedule appointments
3. Cancel appointments
4. See past info